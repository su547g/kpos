************************************************************
      Software Development Kit for StarIO Java
         Readme_En.txt             Star Micronics Co., Ltd. 
************************************************************

 1. Overview
 2. Contents
 3. Copyright
 4. Release History

=============
 1. Overview
=============
   This software is SDK for StarIO Java.
   StarIO is a high level programming tool that simplifies the development
   and creation of software for Star printers. 
   Please refer to document file for the detailed explanation.


=============
 2. Contents
=============
StarIO_Java_SDK_V100
|- Readme_En.txt                       // Release Note(English)
|- Readme_Jp.txt                       // Release Note(Japanese)
|- SoftwareLicenseAgreement.pdf        // Software License Agreement(English)
|- SoftwareLicenseAgreement_jp.pdf     // Software License Agreement(Japanese)
|- Document
|  |- StarIO_Java_SDK_README.pdf       // Master help file
|  +- StarIO_help
|     |- en
|     |  +- StarIO
|     |     +- index.htm               // Help file for StarIO(English)
|     +- ja
|        +- StarIO
|           +- index.htm               // Help file for StarIO(Japanese)
+- Software                            // Sample project file for StarIO Java
   |- Documentation
   |- nbproject
   |- res
   |- src
   +- dependencies
      |- 64
      |  |- stario.jar                 // StarIO component
      |  |- StarIOJ.dll                // StarIO component
      |  +- StarIOPort.dll             // StarIO component
      +- 32
         |- stario.jar                 // StarIO component
         |- StarIOJ.dll                // StarIO component
         +- StarIOPort.dll             // StarIO component


==============
 3. Copyright
==============
Copyright 2011 Star Micronics Co., Ltd. All rights reserved.


====================
 4. Release History
====================
  Ver.1.0.0 
   2011/09/20  First release
